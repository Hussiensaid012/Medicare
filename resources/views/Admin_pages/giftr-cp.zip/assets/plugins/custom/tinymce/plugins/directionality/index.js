// Exports the "directionality" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/directionality')
//   ES2015:
//     import 'tinymce/plugins/directionality'
require('./plugin.js');